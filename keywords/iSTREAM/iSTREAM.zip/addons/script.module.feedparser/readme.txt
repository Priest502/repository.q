Feedparser comes from http://code.google.com/p/feedparser/.
This Repo ist just an XBMC add-on packaged version of the original Code.