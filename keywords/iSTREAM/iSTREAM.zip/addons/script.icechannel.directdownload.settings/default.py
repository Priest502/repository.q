addon_id="script.icechannel.directdownload.settings"
addon_name="iStream - directdownload - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
