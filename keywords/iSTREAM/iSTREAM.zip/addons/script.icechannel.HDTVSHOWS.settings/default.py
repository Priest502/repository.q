addon_id="script.icechannel.HDTVSHOWS.settings"
addon_name="iStream - HDTVSHOWS - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
