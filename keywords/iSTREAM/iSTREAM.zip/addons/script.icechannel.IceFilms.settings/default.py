addon_id="script.icechannel.IceFilms.settings"
addon_name="iStream - IceFilms - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
