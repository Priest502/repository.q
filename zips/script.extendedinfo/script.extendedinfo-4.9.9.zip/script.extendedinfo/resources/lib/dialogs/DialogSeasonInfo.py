# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

from ..Utils import *
from ..TheMovieDB import *
from ..ImageTools import *
from DialogBaseInfo import DialogBaseInfo
from ..WindowManager import wm
from ..OnClickHandler import OnClickHandler
from .. import VideoPlayer

ch = OnClickHandler()
PLAYER = VideoPlayer.VideoPlayer()


def get_season_window(window_type):

    class DialogSeasonInfo(DialogBaseInfo, window_type):

        def __init__(self, *args, **kwargs):
            super(DialogSeasonInfo, self).__init__(*args, **kwargs)
            self.type = "Season"
            self.tvshow_id = kwargs.get('id')
            data = extended_season_info(tvshow_id=self.tvshow_id,
                                        season_number=kwargs.get('season'))
            if not data:
                return None
            self.info, self.data = data
            if "dbid" not in self.info:  # need to add comparing for seasons
                self.info['poster'] = get_file(url=self.info.get("poster", ""))
            self.info['ImageFilter'], self.info['ImageColor'] = filter_image(input_img=self.info.get("poster", ""),
                                                                             radius=25)
            self.listitems = [(2000, self.data["episodes"]),
                              (1150, self.data["videos"]),
                              (1000, self.data["actors"]),
                              (750, self.data["crew"]),
                              (1250, self.data["images"]),
                              (1350, self.data["backdrops"])]

        def onInit(self):
            self.get_youtube_vids("%s %s tv" % (self.info["TVShowTitle"], self.info['title']))
            super(DialogSeasonInfo, self).onInit()
            pass_dict_to_skin(data=self.info,
                              prefix="movie.",
                              window_id=self.window_id)
            self.fill_lists()

        def onClick(self, control_id):
            super(DialogSeasonInfo, self).onClick(control_id)
            ch.serve(control_id, self)

        @ch.click(121)
        def browse_season(self):
            if self.dbid:
                url = "videodb://tvshows/titles/%s/%s/" % ((self.dbid), self.info.get("season", ""))
            else:
                tvdb_id = fetch(get_tvshow_ids(self.tvshow_id), "tvdb_id")
                url = "plugin://plugin.video.metalliq/tv/tvdb/%s/%s/" % (tvdb_id, self.info.get("season", ""))
            self.close()
            xbmc.executebuiltin("ActivateWindow(videos,%s,return)" % url)

        @ch.click(750)
        @ch.click(1000)
        def open_actor_info(self):
            wm.open_actor_info(prev_window=self,
                               actor_id=self.listitem.getProperty("id"))

        @ch.click(2000)
        def open_episode_info(self):
            wm.open_episode_info(prev_window=self,
                                 tvshow=self.info["TVShowTitle"],
                                 tvshow_id=self.tvshow_id,
                                 season=self.listitem.getProperty("season"),
                                 episode=self.listitem.getProperty("episode"))

        @ch.click(10)
        def play_season_no_resume(self):
            if self.dbid:
                url = "special://profile/playlists/video/%s.xsp" % self.info.get("tvdb_id", "")
                if not os.path.exists(url):
                    url = "plugin://plugin.video.metalliq/tv/play/%s/%s/1/%s" % (self.info.get("tvdb_id", ""), self.info.get("season", ""), SETTING("player_main_tv"))
            else:
                url = "plugin://plugin.video.metalliq/tv/play/%s/%s/1/%s" % (self.info.get("tvdb_id", ""), self.info.get("season", ""), SETTING("player_main_tv"))
            PLAYER.qlickplay(url,
                             listitem=None,
                             window=self,
                             dbid=0)

        @ch.click(445)
        def show_manage_dialog(self):
            manage_list = []
            manage_list.append(["[COLOR ff0084ff]E[/COLOR]xtended [COLOR ff0084ff]I[/COLOR]nfo [COLOR ff0084ff]M[/COLOR]od", "Addon.OpenSettings(script.extendedinfo)"])
            manage_list.append(["[COLOR ff0084ff]M[/COLOR]etalli[COLOR ff0084ff]Q[/COLOR]", "Addon.OpenSettings(plugin.video.metalliq)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.1channel)"):
                manage_list.append(["1Channel", "Addon.OpenSettings(plugin.video.1channel)"])
            if xbmc.getCondVisibility("system.hasaddon(script.artworkdownloader)"):
                manage_list.append(["Artwork Downloader", "Addon.OpenSettings(script.artworkdownloader)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.couchpotato_manager)"):
                manage_list.append(["CouchPotato", "Addon.OpenSettings(plugin.video.couchpotato_manager)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.exodus)"):
                manage_list.append(["Exodus", "Addon.OpenSettings(plugin.video.exodus)"])
            if xbmc.getCondVisibility("system.hasaddon(script.icechannel)"):
                manage_list.append(["iSTREAM", "Addon.OpenSettings(script.icechannel)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.phstreams)"):
                manage_list.append(["Phoenix", "Addon.OpenSettings(plugin.video.phstreams)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.pulsar)"):
                manage_list.append(["Pulsar", "Addon.OpenSettings(plugin.video.pulsar)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.quasar)"):
                manage_list.append(["Quasar", "Addon.OpenSettings(plugin.video.quasar)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.saltshd.lite)"):
                manage_list.append(["Salts HD Lite", "Addon.OpenSettings(plugin.video.saltshd.lite)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.saltsrd.lite)"):
                manage_list.append(["Salts RD Lite", "Addon.OpenSettings(plugin.video.saltsrd.lite)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.specto)"):
                manage_list.append(["Specto", "Addon.OpenSettings(plugin.video.specto)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.program.super.favourites)"):
                manage_list.append(["Super Favourites (iSearch)", "Addon.OpenSettings(plugin.program.super.favourites)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.theroyalwe)"):
                manage_list.append(["The Royal We", "Addon.OpenSettings(plugin.video.theroyalwe)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.yifymovies.hd)"):
                manage_list.append(["Yifymovies HD", "Addon.OpenSettings(plugin.video.yifymovies.hd)"])
            if xbmc.getCondVisibility("system.hasaddon(plugin.video.whatthefurk)"):
                manage_list.append(["What The Furk", "Addon.OpenSettings(plugin.video.whatthefurk)"])
            selection = xbmcgui.Dialog().select(heading=LANG(10004),
                                                list=[i[0] for i in manage_list])
            if selection > -1:
                for item in manage_list[selection][1].split("||"):
                    xbmc.executebuiltin(item)

        @ch.click(132)
        def open_text(self):
            wm.open_textviewer(header=LANG(32037),
                               text=self.info["Plot"],
                               color=self.info['ImageColor'])

        @ch.click(350)
        @ch.click(1150)
        def play_youtube_video(self):
            PLAYER.play_youtube_video(youtube_id=self.listitem.getProperty("youtube_id"),
                                      listitem=self.listitem,
                                      window=self)

    return DialogSeasonInfo
