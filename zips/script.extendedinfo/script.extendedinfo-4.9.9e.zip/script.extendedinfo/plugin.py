# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

import sys
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib.process import start_info_actions
from resources.lib.Utils import *


class Main:

    def __init__(self):
        xbmc.log("version %s started" % ADDON_VERSION)
        xbmc.executebuiltin('SetProperty(extendedinfo_running,True,home)')
        self._parse_argv()
        if self.infos:
            start_info_actions(self.infos, self.params)
        else:
            video = {"list&type=video": "yt - %s [I](Youtube)[/I]" % LANG(32231),
                     "list&type=channel": "yt - %s [I](Youtube)[/I]" % LANG(32229),
                     "list&type=playlist": "yt - %s [I](Youtube)[/I]" % LANG(32230),
                    }
            movie = {"trendingmovies": "tr - %s [I](Trakt.tv)[/I]" % LANG(32047),
                     # tmdb
                     "mainmovies": "tm - %s [I](TheMovieDB)[/I]" % LANG(32170),
                     "incinemas": "tm - %s [I](TheMovieDB)[/I]" % LANG(32042),
                     "upcoming": "tm - %s [I](TheMovieDB)[/I]" % LANG(32043),
                     "topratedmovies": "tm - %s [I](TheMovieDB)[/I]" % LANG(32046),
                     "popularmovies": "tm - %s [I](TheMovieDB)[/I]" % LANG(32044),
                     "accountlists": "tm - %s [I](TheMovieDB)[/I]" % LANG(32045),
                     "starredmovies": "tm - %s [I](TheMovieDB)[/I]" % LANG(32134),
                     "ratedmovies": "tm - %s [I](TheMovieDB)[/I]" % LANG(32135),
                     }
            tvshow = {"aired": "tr - %s [I](Trakt.tv)[/I]" % LANG(32028),
                      "premiered": "tr - %s [I](Trakt.tv)[/I]" % LANG(32029),
                      "trendingshows": "tr - %s [I](Trakt.tv)[/I]" % LANG(32032),
                      # tmdb
                      "maintvshows": "tm - %s [I](TheMovieDB)[/I]" % LANG(32177),
                      "airingtodaytvshows": "tm - %s [I](TheMovieDB)[/I]" % LANG(32038),
                      "onairtvshows": "tm - %s [I](TheMovieDB)[/I]" % LANG(32039),
                      "topratedtvshows": "tm - %s [I](TheMovieDB)[/I]" % LANG(32040),
                      "populartvshows": "tm - %s [I](TheMovieDB)[/I]" % LANG(32041),
                      "starredtvshows": "tm - %s [I](TheMovieDB)[/I]" % LANG(32144),
                      "ratedtvshows": "tm - %s [I](TheMovieDB)[/I]" % LANG(32145),
                      }
            xbmcplugin.setContent(self.handle, 'movies')
            items = merge_dicts(video, movie, tvshow)
            for key, value in iter(sorted(items.iteritems())):
                temp = {}
                temp['value'] = value
                image_code = temp['value'][:2]
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, iconImage="special://home/addons/script.extendedinfo/resources/skins/Default/media/%s.png" % image_code)
                li.setProperty('fanart_image', "special://home/addons/script.extendedinfo/resources/skins/Default/media/%s-fanart.jpg" % image_code)
                url = 'plugin://script.extendedinfo?info=%s' % key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url,
                                            listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(self.handle)
        xbmc.executebuiltin('ClearProperty(extendedinfo_running,home)')

    def _parse_argv(self):
        args = sys.argv[2][1:]
        self.handle = int(sys.argv[1])
        self.control = "plugin"
        self.infos = []
        self.params = {"handle": self.handle,
                       "control": self.control}
        if args.startswith("---"):
            delimiter = "&"
            args = args[3:]
        else:
            delimiter = "&"
        for arg in args.split(delimiter):
            param = arg.replace('"', '').replace("'", " ")
            if param.startswith('info='):
                self.infos.append(param[5:])
            else:
                try:
                    self.params[param.split("=")[0].lower()] = "=".join(param.split("=")[1:]).strip()
                except:
                    pass

if (__name__ == "__main__"):
    Main()
xbmc.log('finished')
